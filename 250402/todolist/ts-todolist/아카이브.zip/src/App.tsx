import styled from "styled-components";
import GlobalStyles from "./styles/GlobalStyles.styles";
import Title from "./components/Title";
import ToDoList from "./components/ToDoList";

const Container = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const mockData = ["React 공부하기", "운동하기", "책읽기"];

function App() {
  return (
    <>
      <GlobalStyles />
      <Container>
        <Title label="할 일 목록" />
        <ToDoList toDoList={mockData} />
      </Container>
    </>
  );
}

export default App;
