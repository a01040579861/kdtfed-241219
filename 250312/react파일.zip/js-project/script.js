// document.querySelector("button").addEventListener("click", () => {
//   alert("Button Clicked!");
// });

const handleClick = () => {
  alert("Button Clicked!");
};
