import GlobalStyles from "./styles/GlobalStyles.styles";

function App() {
  return (
    <>
      <GlobalStyles />
      <h1>Hello</h1>
    </>
  );
}

export default App;
